import { StackActions } from '@react-navigation/native';
import { StatusBar } from 'expo-status-bar';
import {Image, TouchableOpacity} from 'react-native' ; 
import { StyleSheet, Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
export default function App({navigation}) {
  
  const getFullName = () => {
   navigation.navigate('second');
    return ;
  }
  
  
  return (
    <><View style={styles.container}>
          <Text style={styles.st2}>Terminal Exam BCS-094</Text>
      
      
    </View><View styles={styles.heading}>
    <TouchableOpacity style={styles.button} onPress={getFullName}>
      <Text style={styles.st2}>Start</Text>
    </TouchableOpacity>


    </View></>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop:50,
  

    
    backgroundColor: 'green',
    
    justifyContent: 'center',
  },
  st2:{
    textAlign:'center',
    justifyContent:'center',
    
    fontSize:30,
    

  },
  st:{marginLeft:100,
    
    fontSize:30,
    
    
  },
  heading:{
    flexDirection:'',
    backgroundColor:'red'
 

  },
  button:{marginTop:20,
    marginLeft:145,
    justifyContent:'center',
    alignItems:"center",
    backgroundColor:'yellow',
    fontSize:40,
    width:100,
    height:100,
    borderRadius:50,
  }

});
