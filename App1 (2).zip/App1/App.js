import { StatusBar } from 'expo-status-bar';
import {Image, TouchableOpacity} from 'react-native' ; 
import { StyleSheet, Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import App2 from './assets/App2';
import App3 from './assets/App3';
import App4 from './assets/App4';

import { createStackNavigator } from '@react-navigation/stack';
const getFullName = () => {
  
  return ;
}



export default function App() {
  const Stack=createStackNavigator(); 
  return (
    
    <>
    <NavigationContainer>
      <Stack.Navigator initialRouteName='First'>
        <Stack.Screen name="First" component={App2 }/>
<Stack.Screen name="second" component={App3}/>
<Stack.Screen name="Third" component={App4}/>
      </Stack.Navigator>
    </NavigationContainer>
    
    <View style={styles.container}>
         

    </View></>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop:50,
  

    
    backgroundColor: 'green',
    
    justifyContent: 'center',
  },
  h1:{
fontSize:10,
color:'blue',
  },
  st2:{
    textAlign:'center',
    justifyContent:'center',
    
    fontSize:30,
    

  },
  st:{marginLeft:100,
    
    fontSize:30,
    
    
  },
  heading:{
    flexDirection:'',
    backgroundColor:'red'
 

  },
  button:{marginTop:20,
    marginLeft:145,
    justifyContent:'center',
    alignItems:"center",
    backgroundColor:'yellow',
    fontSize:40,
    width:100,
    height:100,
    borderRadius:50,
  }

});
